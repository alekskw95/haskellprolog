listaPierwszychElementow :: [[Int]] -> [Int]
listaPierwszychElementow [] = []
listaPierwszychElementow ((x:xs):xss) = x : listaPierwszychElementow xss

listaPierwszychElementow' :: [[Int]] -> [Int]
listaPierwszychElementow' [] = []
listaPierwszychElementow' (x:xs) = if x==[] then listaPierwszychElementow' xs else head x : listaPierwszychElementow' xs
{-
Zadanie 1 
Zdefiniuj rekurencyjną funkcje w Haskellu listaOstatnichElementow która dla zadanej 
listy list stworzy listę jej ostatnich elementów. 
Np. listaOstatnichElementow [[4,5],[1,2,3],[8],[7,6,9]] -> [5,3,8,9] 
Uwzględnij również przypadek listy pustej, 
tzn. listaOstatnichElementow [[4,5],[],[7,8]] -> [5,8]
-}
listaOstatnichElementow :: [[Int]] -> [Int]
listaOstatnichElementow [] = []
listaOstatnichElementow (x:xs) = last x : listaOstatnichElementow xs

listaOstatnichElementow' :: [[Int]] -> [Int]
listaOstatnichElementow' [] = []
listaOstatnichElementow' (x:xs) = if x==[] then listaOstatnichElementow' xs else last x : listaOstatnichElementow' xs

{-
Zadanie 2 
Napisz program w Haskellu który wczyta z klawiatury trzy liczby całkowite 
i wyświetli na ekran środkową z tych liczb (powiemy, że liczba x jest liczbą środkową 
wśród liczb x,y i z, gdy y <= x <= z   lub   z <= x <= y). 
-}
{-dajSrodkowa :: Int -> Int -> Int -> Int
dajSrodkowa x y z =
    if (y <= x && x <= z)
        then x
    else if (z <= x && x<= y)
        then x
    else
        error "Brak srodkowej liczby"
-}

--wydaje mi się, ze tutaj dali przykład z tym x, a to ma się tyczyć wszystkich i zawsze jakaś środkowa się znajdzie

dajSrodkowa :: Int -> Int -> Int -> Int
dajSrodkowa x y z =
    if ((y <= x && x <= z)  ||  (z <= x && x<= y) )
        then x
    else if ((x <= y && y <= z)  ||  (z <= y && y<= x) )
        then y
    else if ((x <= z && z <= y)  ||  (y <= z && z<= x) )
        then z
    else
        error "Brak srodkowej liczby"

{-
Zadanie 3 
Zdefiniuj w Prologu rekurencyjną funkcję dodajListy(A,B,R) który dla dwóch danych 
list liczbowych A i B utworzy listę R sum jej elementów na odpowiadających sobie pozycjach. 
Np. dodajListy([1,2,3],[4,5,6],R). R=[5,7,9]
-}
{-dodajListy :: ([Int], [Int], String) -> String
dodajListy (x, y, r) = r ++ " = " ++ show(listaL(x)(y))

listaL [] [] = []
listaL (x:xs) (y:ys) = x+y : listaL xs ys-}

dodajListy :: ([Int], [Int], String) -> String
dodajListy (x, y, r) = r ++ " = " ++ show(listaL(x)(y))

{-
potraktowałam, to tak, ze gdyby druga lista była pusta, to przepisuje elementy z tej jednej 
np.   dodajListy([1,2,3,4],[1,2],"R")   zwróci , R = [2,4,3,4]
a jak zapiszemy :
listaL _ [] = []
listaL [] _ = []   
w miejsce 2 i 3 linijki funkcji listaL, to po prostu skończymy dodawanie w momencie, w którym jedna lista się skończy 
np.   dodajListy([1,2,3,4],[1,2],"R")    zwróci R=[2,4] 
-}

listaL [] [] = []
listaL (x:xs) [] = x : listaL xs []
listaL [] (x:xs) = x : listaL [] xs
listaL (x:xs) (y:ys) = x+y : listaL xs ys




dajOstatni :: [a] -> [a]
dajOstatni [] = []
dajOstatni x = [last x]

listaOst :: [[a]] -> [a]
listaOst [] = []
listaOst [[]] = []
listaOst (x:xs) = dajOstatni x ++ listaOst xs