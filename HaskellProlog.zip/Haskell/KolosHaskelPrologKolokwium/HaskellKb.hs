import System.IO
import Data.Char
{-
Zadanie 4 
Zdefiniuj w Prologu predykat 
max2(X,Y,Z) 
który dla dwóch liczb X i Y wyznaczy większą z nich, a następnie napisz w Prologu program, 
który odczyta z klawiatury dwie liczby (zakładamy , że użytkownik musi je podać) i jeśli są 
one obie dodatnie to do pliku plik.txt zapisze maximum z tych liczb, a w przeciwnym przypadku 
do pliku plik.txt zapisze liczbę -1

Chciałam zrobić max(X,Y) i pozniej podanie od uzytkownika X i Y i zapis do pliku w Haskellu
-}


dajWieksza :: Int -> Int -> Int
dajWieksza x y = max x y

doPliku = do
    putStr "Podaj x\t"
    var1 <- getLine
    putStr "Podaj y\t"
    var2 <- getLine
    let x = (read var1::Int)
    let y = (read var2::Int)
    let liczba = dajWieksza x y 
    let liczbaDoPliku = show(if (x > 0 && y > 0) then liczba else (-1))
    writeFile "F:\\DellPulpit\\ParadygmatyIJProg\\fileLiczba.txt" (liczbaDoPliku)
    putStrLn $ "Podano " ++ show(x) ++ " oraz " ++ show(y) ++ ", max = " ++ show(liczba)