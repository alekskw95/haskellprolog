--Zadanie 1
sumPositiveOnList :: [Int] -> Int
sumPositiveOnList [] = 0
sumPositiveOnList (x:xs) = (if (x>0) then x else 0) + sumPositiveOnList xs

--Zadanie 2
count :: Num p => (t -> Bool) -> [t] -> p
count x y = fromIntegral $ length d
    where d = filter x y

--Zadanie 3
sumTwoNumber :: Integer -> Integer -> String
sumTwoNumber x y = "suma " ++ show(x + y) ++ " roznica " ++ show(x - y)

--Zadanie 4
{-podajDane :: a -> Int -> [a]
podajDane x 0 = []
podajDane x y = x : podajDane x (y-1)-}

{-podajDane :: a -> Int -> [a]
podajDane x y =
    if y < 0 then [ x | _ <- [1..2]]
        else [ x | _ <- [1..y]]-}
		
podajDane :: a -> Int -> [a]
podajDane x y 
    | y > 0 = [ x | _ <- [1..y]]--x : podajDane x (y-1)
    | y < 0 = error "Bledna wartosc n"
    | otherwise = error "??"