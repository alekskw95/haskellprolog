{-
Zad 1
=====

Napisz funkcje trzeciZListy, ktora wyznaczy trzeci element listy,
a w przypadku listy pustej, jednoelementowej lub dwuelementowej zwrocic blad.

(nie wolno korzystac z wbudowanych funkcji)


Np.
              trzeciZListy [3,4,7,8] -> 7
    
              trzeciZListy [] -> blad
-}
trzeciZListy :: [Int] -> Int
trzeciZListy [] = error "Blad"
trzeciZListy (_:_:x:xs) = x

{-
Zad 2
=====

Napisz program w ktorym wczytujesz trzy liczby rzeczywiste z klawiatury
i wypisujesz na ekran najwieksza z nich.


(nie wolno korzystac z wbudowanych funkcji)
-}

wczytajLiczby :: Int -> Int -> Int -> Int
wczytajLiczby x y z =
    if (x>y && x>z)
        then x
    else if (y>x && y>z)
        then y
    else if (z>x && z>y)
        then z
    else 
        error "Blad"


{-
Zad 3
=====

Napisz funkcje ktora dla zadanej listy trzyelementowych krotek wyznaczy
liste ich sum.

Np.

       policzSumeKrotek [(3,2,7),(1,4,3),(1,2,4),(6,5,4)] -> [12,8,7,15]-}

policzSumeKrotek :: [(Int, Int, Int)] -> [Int]
policzSumeKrotek [] = []
policzSumeKrotek (x:xs) = krotka(x) : policzSumeKrotek xs--tu x jest juz krotką 3 -elementowa

krotka :: (Int, Int, Int) -> Int
krotka (x, y, z) = x +y + z 



{-
Zad 4
=====

Napisz funkcje parzystaNieparzysta, ktora dla zadanej listy liczb calkowitych
zwroci liste napisow "P" i "N".

Np.

    
       parzystaNieparzysta [3,2,4,1,3,6,7,3] -> ["N","P","P","N","N","P","N","N"] -}

parzystaNieparzysta :: [Int] -> [String]
parzystaNieparzysta [] = []
parzystaNieparzysta (x:xs) = ( if (x `mod` 2 == 0) then "P" else "N") : parzystaNieparzysta xs