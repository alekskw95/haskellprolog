import System.IO

main = do
 hSetBuffering stdout NoBuffering
 putStr "Podaj lancuch = "
 a <- getLine
 putStr "Podaj liczbe naturalna = "
 b <- getLine
 putStrLn $ sN (read b :: Int) a

sN n s
    | n < 0 = "Bledna wartosc n"
	| n == 0 = ""
	| otherwise = s ++ " " ++ sN (n-1) s

	
	
czytajPlik = do
 handle <- openFile "F:\\DellPulpit\\ParadygmatyIJProg\\HaskellZajęcia4\\test1.txt" ReadMode
 tekst <- hGetContents handle
 putStrLn tekst
 hClose handle