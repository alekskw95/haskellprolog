import System.IO

--Zadanie 1
{-Zdefiniować funkcję

		sumPositiveOnList :: [Int] -> Int
		
która oblicza sumę liczb dodatnich z listy podanej jako argument.-}
sumPositiveOnList :: [Int] -> Int
sumPositiveOnList [] = 0
sumPositiveOnList (x:xs) = (if (x>0) then x else 0) + sumPositiveOnList xs

--Zadanie 2
{-Zdefiniować funkcję

		count :: Num p => (t -> Bool) -> [t] -> p
		
która oblicza, ile elementów listy spełnia podany warunek logiczny.

Na przykład:

count (<2) [3,1,0,3,2,1]						daje liczbę 3, 

count (==3) [3,1,0,3,2,1]						daje liczbę 2,

count (=='a') "Ala ma kota, a Ola psa"					daje liczbę 6.	
-}
count :: Num p => (t->Bool) -> [t] -> p --funkcja logiczna, drugim el jest lista elementow okreslonego typu
count x y = fromIntegral $ length d
    where d = filter x y
--Main> sum (filter (>0) [-2,4,5,6])

--rekurencyjnie
count2 :: Num p => (t->Bool) -> [t] -> p
count2 _ [] = 0
count2 f (x:xs) = (if f x == True then 1 else 0) + count2 f xs 

--Zadanie 3
{-Zdefiniować funkcję, która wczytuje podane przez użytkownika 2 liczby, a następnie oblicza i wyświetla ich sumę i różnicę.-}
twoNumber :: Int -> Int -> String
twoNumber x y = "suma: " ++ show(x+y) ++ " roznica: " ++ show(x-y)




dzialaj = do--putStrLn "hello"
 putStr "Podaj a = "
 a <- getLine
 putStr "Podaj b = "
 b <- getLine
 putStrLn ("a+b = " ++ show ((read a :: Double) + (read b :: Double)))
 putStrLn ("a-b = " ++ show ((read a :: Double) - (read b :: Double)))





-- Zadanie 4
{-Zdefiniować funkcję, która wczytuje podany przez użytkownika łańcuch znakowy s oraz liczbę naturalną n, a następnie wyświetla na ekranie n razy łańcuch s. Jeśli użytkownik poda n ujemne, funkcja ma wyświetlić komunikat "Bledna wartosc n".-}
podajDane :: a -> Int -> [a]
podajDane x y
    | y > 0 = [x | _<-[1..y]]
    | otherwise = error "Bledna wartosc n"

--2 sposob

sN n s
    | n < 0 = "Bledna wartosc n"
	| n == 0 = ""
	| otherwise = s ++ " " ++ sN (n-1) s

{-dzialaj2 = do
 putStr "Podaj lancuch = "
 a <- getLine
 putStr "Podaj liczbe naturalna = "
 b <- getLine
 putStrLn $ sN (read b :: Int) a-}

main = do
 putStr "Podaj lancuch = "
 a <- getLine
 putStr "Podaj liczbe naturalna = "
 b <- getLine
 putStrLn $ sN (read b :: Int) a
 
{-*Main> dzialaj2
Podaj lancuch = Minionek
Podaj liczbe naturalna = 6
Minionek Minionek Minionek Minionek Minionek Minionek
*Main> dzialaj2
Podaj lancuch = Minionek
Podaj liczbe naturalna = (-6)
Bledna wartosc n
*Main> dzialaj2
Podaj lancuch = Minionek
Podaj liczbe naturalna = 0-}