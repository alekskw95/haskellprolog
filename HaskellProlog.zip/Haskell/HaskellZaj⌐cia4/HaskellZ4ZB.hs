--Zadanie 5
{-Napisać program (lub funkcję), który wyświetla na ekranie zawartość podanego pliku.-}
