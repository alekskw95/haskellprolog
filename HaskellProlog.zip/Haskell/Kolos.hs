import Data.Char
import Data.List
policzSumeKrotek :: [(Int, Int, Int)] -> Int
policzSumeKrotek [] = 0
policzSumeKrotek (x:xs) = krotka(x) + policzSumeKrotek xs--tu x jest juz krotką 3 -elementowa

krotka :: (Int, Int, Int) -> Int
krotka (x, y, z) = x +y + z 

--policzSumeKrotek [(3,2,7),(1,4,3),(1,2,4),(6,5,4)] -> 42


--------

policzSumeList :: [[Int]] -> Int
policzSumeList [] = 0
policzSumeList (x:xs) = sum x + policzSumeList xs

policzSumeList' :: [[Int]] -> Int
policzSumeList' [] = 0
policzSumeList' (x:xs) = lista'(x) + policzSumeList' xs

lista' :: [Int] -> Int
lista' [] = 0
lista' (x:xs) = x + lista' xs
-- policzSumeList [[3,2,7],[1,4,3],[1,2,4],[6,5,4]] -> 42

--------
reverseList :: [Int] -> [Int]
reverseList  [] = []
reverseList  xs = last xs : reverseList (init xs)

reverse' :: [a] -> [a]  
reverse' [] = []  
reverse' (x:xs) = reverse' xs ++ [x] 

dodajListy :: [Int] -> [Int] -> [Int]
dodajListy [] [] = []
dodajListy [] [x] = [x]
dodajListy [x] [] = [x]
dodajListy (x:xs) ys = x + last ys : dodajListy xs (init ys)

{-
*Main> dodajListy [3,2,7] [1,2,4]
[7,4,8]
*Main> dodajListy [3,2,7,6] [1,2,4]
[7,4,8,6]
*Main> dodajListy [3,2,7] [1,2,4,8]
[11,6,9,1]-}

coDrugi :: [Int] -> [Int]
coDrugi [] = []
coDrugi (x:y:xs) = y : coDrugi xs

coDrugi' :: [Int] -> [Int]
coDrugi' [] = []
coDrugi' (x:y:xs) = x : coDrugi' xs

coDrugi'' :: [Int] -> [Int]
coDrugi'' [] = []
coDrugi'' (x:y:xs) = x+y : coDrugi'' xs

dodaj' :: [Int] -> [Int]
dodaj' [] = []
dodaj' [x] = [x]
dodaj' (x:xs) = x+last xs : dodaj' (init xs)

dodajEnd :: [Int] -> [Int] -> [Int]
dodajEnd [] [] = []
dodajEnd [x] [] = [x]
dodajEnd [] [x] = [x]
dodajEnd xs ys = last xs + last ys : dodajEnd (init xs) (init ys)


obrocListe :: [Int] -> [Int]
obrocListe [] = []
obrocListe xs = last xs : obrocListe (init xs)


elementyDodatnie :: [Int] -> Int
elementyDodatnie [] = 0
elementyDodatnie (x:xs) = if (x>0) then x + elementyDodatnie xs else elementyDodatnie xs

trans :: [[a]] -> [[a]]
trans [] = []
trans ([]:xss) = trans xss
trans ((x:xs):xss) = (x : fmap head' xss) : trans (xs : fmap tail' xss)
    where head' (x:_) = x
          tail' (_:xs) = xs


uppercase :: String -> String
uppercase = map (\c -> if c >= 'a' && c <= 'z' then toEnum (fromEnum c - 32) else c)

lowercase :: String -> String
lowercase = map (\c -> if c >= 'A' && c <= 'Z' then toEnum (fromEnum c + 32) else c)

list4 :: Char -> [Char] -> Int
list4 ' ' " " = error "P"
list4 x y = length [z | z<-y, z==x]

firstFromList (x:xs) = x

remSort :: (Ord a) => [a] -> [a]
remSort = sort . nub

listaWiersze []= []
listaWiersze (x:xs) = x ++ "\n"++ listaWiersze xs

drukWiersze x = putStr . listaWiersze $ map show x

listaKrotek = [(a,b,c) | a<-[0..51], b<-[0..51], c<-[0..51], a+b+c == 51, a/=b, a/=c, b/=c, a`mod` 2 /= 0, b `mod` 2 /= 0, c `mod` 2 /= 0]

ost :: String -> Char
ost [] ='!'
ost x = head (reverse x)

pary = [(a ,b) | a <- [10,11..1000] , b <- [10,11..1000], a `mod` 2 == 0, b `mod` 2 == 0, a*b==10000, a/=b]