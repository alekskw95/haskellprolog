{-Zad. 7.
=======
Zdefiniować funkcję, która wypisuje z podanego łańcucha znakowego:

a) tylko małe litery;

b) tylko wielkie litery;

c) wszystkie znaki, które nie są cyframi.-}

--Zad 7a
{-isLower :: Char -> Bool
isLower c = c >= 'a' && c <= 'z'
maleLitery a  = filter isLower a-}
removeUppercase st = [ c | c <- st , c `elem ` ['a' .. 'z']]

--Zad 7b
{-isUpper :: Char -> Bool
isUpper c = c >= 'A' && c <= 'Z'
duzeLitery a  = filter isUpper a-}
removeNonUppercase st = [ c | c <- st , c `elem` ['A' .. 'Z']]

--Zad 7c
{-isNoDigit :: Char -> Bool
isNoDigit c = not (c >= '0' && c <= '9')
znakiBezCyfr a  = filter isNoDigit a-}
removeDigit st = [ c | c <- st , c `notElem` ['1' .. '9']]






