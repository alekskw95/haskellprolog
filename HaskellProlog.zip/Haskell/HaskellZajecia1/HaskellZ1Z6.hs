{- Zad. 6.
=======
Zdefiniować listę liczb trzycyfrowych podzielnych przez 3 o różnych cyfrach (są to m.in. liczby 102, 105, 459, 987). -}

listaMod = [100*x + 10*y + z | x<-[1..9] , y<-[0..9] , z<-[0..9], x/=y, x/=z, y/=z, (100*x + 10*y + z) `mod` 3 == 0 ]