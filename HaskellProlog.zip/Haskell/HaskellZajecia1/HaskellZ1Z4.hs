{- Zad. 4.
=======
Zdefiniować funkcję o nazwie inicjaly, która przy podaniu imienia i nazwiska (dwa łańcuchy znakowe) wyświetli inicjały osoby (z kropkami po pierwszych literach imienia i nzawiska), np.

inicjaly "Anna" "Lis"

da efekt:  "A.L." -}

{- inicjaly :: String -> String -> String -- rekurencyjna wersja
inicjaly firstname lastname = [f] ++ ". " ++ [l] ++ "."
  where (f:_) = firstname 
        (l:_) = lastname-}
inicjaly :: [Char] -> [Char] -> String
inicjaly fistname lastname = [head fistname] ++ ". " ++ [head lastname] ++ "."