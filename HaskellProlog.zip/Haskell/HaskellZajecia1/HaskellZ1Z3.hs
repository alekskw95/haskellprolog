{- Zad. 3.
=======
a) Zdefiniować funkcję o nazwie podwajam, która liczbę podaną jako argument mnoży przez 2.	 
 
b) Zdefiniować listę o nazwie liczby, której elementy to: 11, 12, 13, ..., 99.

c) Zastosować funkcje map i podwajam w celu uzyskania listy dwukrotności liczb z listy liczby.

d) Zdefiniować funkcję o nazwie mod13, która z podanej listy liczb wyświetli liczby podzielne przez 13. Zastosować tę funkcję dla listy liczby. -}

--Zadanie 3a
podwajam :: Integer -> Integer
podwajam x = x*2

--Zadanie 3b
--a1=[11..99]
a1=[11,12..99]

--Zadanie 3c
--map podwajam a1 -- w interpreterze

--Zadanie 3d
mod13 :: [Integer] -> [Integer]
mod13 x = [y | y<-a1, y `mod` 13 == 0]