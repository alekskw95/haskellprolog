{- Zad. 5.
=======
Zdefiniować funkcję o nazwie unitaryN, która zbuduje macierz jednostkową podanego stopnia. Przykładowo, jeśli zastosujemy 

unitaryN 5

uzyskamy na ekranie

[[1,0,0,0,0],[0,1,0,0,0],[0,0,1,0,0],[0,0,0,1,0],[0,0,0,0,1]] -}

unitaryN n = [[if i==j then 1 else 0 | i<-[1..n]] | j<-[1..n]]