{-Zad. 2.
=======
Zdefiniować funkcję o nazwie objetosc, która oblicza objetość prostopadłościanu o bokach o długościach x, y, z. -}

objetosc :: Integer -> Integer -> Integer -> Integer
objetosc x y z = x*y*z