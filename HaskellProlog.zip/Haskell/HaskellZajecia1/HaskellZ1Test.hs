dodaj :: Double -> Double -> Double
dodaj x y = x+y

--a1::Double
a1=[2.4, 6, 8, 9]
--a1=[2.4, 6, 8, 9]