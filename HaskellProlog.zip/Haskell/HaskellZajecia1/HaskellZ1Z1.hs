{- Zad. 1.
=======
Zdefiniować funkcję o nazwie witaj, która wywołana z argumentem typu String wydrukuje na ekranie tekst powitania z użyciem tego łańcucha, np.

witaj "Marek"

da na ekranie efekt:

"Witaj Marek!!!"

Wskazówka: W celu łączenia łańcuchów znakowych stosujemy operator ++ -}

witaj ::  String -> String
witaj name = "Witaj " ++ name ++ "!!!"