{-
Zad 1
=====

Napisz predykat

			czyPodzielnaPrzez3iDodatnia(X)
			
ktory dla zadanej liczby X wypisze true jeli liczba X jest dodatnia i podzielna przez 3, a w przeciwnym razie wypisze false.
-}
czyPodzielnaPrzez3iDodatnia :: Integer -> Bool
czyPodzielnaPrzez3iDodatnia x = (if (x>0 && (x `mod` 3==0)) then True else False) 

czyPodzielnaPrzez3iDodatnia' :: (Integer) -> Bool
czyPodzielnaPrzez3iDodatnia' x = (if (x>0 && (x `mod` 3==0)) then True else False) 
{-

Zad 2
=====

Napisz predykat

			iloczynLiczb(R,X)

ktory dla zadanej listy liczb X wyznaczy iloczyn R jej elementow.

Np.

			iloczynLiczb(R,[1,2,3])
			
zwroci

			R=6.-}
iloczynLiczb' :: (Int, [Int]) -> Int
iloczynLiczb' (_, []) = 1
iloczynLiczb' (z, (x:xs)) = x * iloczynLiczb' (z, xs)

iloczynLiczb :: (String, [Int]) -> String
iloczynLiczb (r, x) = r ++  "= " ++ show(iloczyn(x))

iloczyn[]=1
iloczyn(x:xs) = x * iloczyn xs
{-
Zad 3
=====

Zdefiniuj predykat

			funX(A,B,R)

ktory dla dwoch zadanych liczb A i B zwroci:
a)  1 jesli iloczyn A*B jest liczba dodatnia,
b) -1 jesli iloczyn A*B jest liczba ujemna,
c)  0 jesli iloczyn A*B jest rowny 0.-}
funX :: (Int, Int) -> Int
funX (x, y) =
    if (x*y > 0)
        then 1
    else if (x*y < 0)
        then (-1)
    else if (x*y == 0)
        then 0
    else
        error "Blad"
{-

Zad 4
=====

Napisz program ktory pobierze od uzytkownika trzy liczby i wypisze na ekran najmniejsza z nich.-}
podajLiczby :: Int -> Int -> Int -> Int
podajLiczby x y z = min (min x y) z

podajLiczby2 :: Int -> Int -> Int -> Int
podajLiczby2 x y z =
    if (x<y && x<z)
        then x
    else if (y<x && y<z)
        then y
    else
        z


podajLiczby3 :: Int -> Int -> Int -> Int
podajLiczby3 x y z
    |((x<y) && (x<z)) = x
    |((y<x) && (y<z)) = y
    |((z<x) && (z<y)) = z
    | otherwise  = error "Brak"