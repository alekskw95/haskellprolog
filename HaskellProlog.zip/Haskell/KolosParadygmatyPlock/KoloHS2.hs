{-
Zad 1
-----

Napisz program

	obliczSredniaGeome

ktory wczyta z klawiatury dwie liczby i wypisze na ekran ich srednia geometryczna,
przy czym jesli ktoras z liczb jest ujemna to zglosi odpowiedni blad.-}
obliczSredniaGeome :: Double -> Double -> Double
obliczSredniaGeome x y-- = sqrt(x*y)
    |x>0 && y>0 = sqrt(x*y)
    |otherwise = error "Obie liczby musza byc >0"

sredniaGeo = do                       --to wywołujemy
 putStr "Podaj x = "
 x <- getLine
 putStr "Podaj y = "
 y <- getLine
 putStrLn ( "max = " ++ show(obliczSredniaGeome (read x :: Double) (read y :: Double)))
 
{-

Zad 2
-----

Wygeneruj liste par liczb

	(a,b)

takich, że:

1) liczby a,b sš całkowite i z przedziału [10,1000]
2) liczby a,b sš parzyste,
3) a*b=10000,
4) a<>b.-}
-- 1)
para_1 = [(a ,b) | a <- [10,11..1000] , b <- [10,11..1000]] --take 15 para_1

--NIE WIEM CZY PRZYPADEK 2,3,4 MA TEŻ UWZGLĘDNIAĆ LICZBY UJEMNE, UZNAŁAM, ZE NIE
-- 2)
para_2 = [(a ,b) | a <- [0,2..] , b <- [0,2..]] --take 15 para_2

-- 3)
para_3 = [(a ,b) | a <- [0..10000] , b <- [0..10000], a+b==10000] --take 15 para_3

-- 4)
para_4 = [(a ,b) | a <- [0,1..] , b <- [0,1..], a/=b] --take 15 para_4

{-
Zad 3
-----

Zdefiniuj funkcje


                   listaSumList

ktora dla zadanej listy list liczb calkowitych stworzy liste jej sum.

Np. listaSumList [[4,5],[1,2,3],[5],[7,6,5]] -> [9,6,5,18]	
-}
listaSumList :: [[Integer]] -> [Integer]
listaSumList [] = []
listaSumList (x:xs) = sum x : listaSumList xs
{-
Zad 4
-----

Zdefiniuj rekurencyjna funkcje

		ileElementowDodatnich :: [Int] -> Int

ktora obliczy ile jest liczb calkowitych dodatnich na danej liscie liczb calkowitych.

Np.            ileElementowDodatnich [-5,4,-2,-7,1,9,5] -> 4-}
ileElementowDodatnich :: [Int] -> Int
ileElementowDodatnich [] = 0
ileElementowDodatnich (x:xs) = (if (x>0) then 1 else 0) + ileElementowDodatnich xs

{-

Zad 2
-----

Wygeneruj liste par liczb

	(a,b)

takich, że:

1) liczby a,b sš całkowite i z przedziału [10,1000]
2) liczby a,b sš parzyste,
3) a*b=10000,
4) a<>b.-}
krotkiA = [(a,b) | a<-[1..1000], b<-[1..1000]]
krotkiB = [(a,b) | a<-[1..20], b<-[1..20], even a , even b]
krotkiC = [(a,b) | a<-[1..1000], b<-[1..1000], (a*b)==10000]