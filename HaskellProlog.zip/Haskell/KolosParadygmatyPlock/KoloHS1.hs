{-Zad 1
-----

Napisz program

	obliczMax3

ktory wczyta z klawiatury trzy liczby i wypisze na ekran najwieksza z nich.-}
{-obliczMax3 :: Int -> Int -> Int -> Int
obliczMax3 x y z = max (max x y) z-}
obliczMax3 :: Int -> Int -> Int -> Int
obliczMax3 x y z =
    if (x>=y && x>=z)
        then x
    else if (y>=x && y>=z)
        then y
    else if (z>=x && z>=y)
        then z
    else
        0

max3 = do                       --to wywołujemy
 putStr "Podaj x = "
 x <- getLine
 putStr "Podaj y = "
 y <- getLine
 putStr "Podaj z = "
 z <- getLine
 putStrLn ( "max = " ++ show(obliczMax3 (read x :: Int) (read y :: Int) (read z :: Int)))
 
{-Zad 3
-----

Zdefiniuj funkcje


                   listaPierwszychElementow

ktora dla zadanej listy list stworzy liste jej pierwszych elementow.

Np. listaPierwszychElementow [[4,5],[1,2,3],[5],[7,6,5]] -> [4,1,5,7]	
-}
listaPierwszychElementow :: [[Integer]] -> [Integer]
listaPierwszychElementow xs = [head x | x <- xs, not(null x)]

{-Zad 4
-----

Zdefiniuj rekurencyjna funkcje

		ileElementowWiekszychOdX :: (Ord a) => [a] -> a -> Int

ktora zlicza ile jest elementow w danej liscie wiekszych od ustalonego elementu.

Np.            ileElementowWiekszychOdX [5,4,2,7,1,9,5] 3 -> 5-}
ileElementowWiekszychOdX :: (Ord a) => [a] -> a -> Int
ileElementowWiekszychOdX [] _ = 0
ileElementowWiekszychOdX (x:xs) y = (if (x>y) then 1 else 0) + ileElementowWiekszychOdX xs y





{-
 Zad 2
-----

Wygeneruj liste krotek trzyelementowych liczb

	(a,b,c)

takich, że:

1) liczby a,b,c sa całkowite i nieujemne
2) liczby a,b,c sa nieparzyste,
3) a+b+c=51,
4) a<>b, a<>c i b<>c. -}

-- > triangles = [ (a ,b ,c) | c <- [1..10] , b <- [1..10] , a <- [1..10] ]funkcja triangles wypisze wszystkie możliwe kombinacje 3 elem. krotek 

-- 1)
krotki_1 = [(a ,b ,c) | a <- [0..] , b <- [0..] , c <- [0..]] --take 15 krotki_1

--NIE WIEM CZY PRZYPADEK 2,3,4 MA TEŻ UWZGLĘDNIAĆ LICZBY UJEMNE, UZNAŁAM, ZE NIE
-- 2)
krotki_2 = [(a ,b ,c) | a <- [1,3..] , b <- [1,3..] , c <- [1,3..]] --take 15 krotki_2

-- 3)
krotki_3 = [(a ,b ,c) | a <- [0..51] , b <- [0..51] , c <- [0..51], a+b+c==51] --krotki_3    skoro suma ma być równa 51, to z skrajnym przypadku jedna z wartości jest maksymalnie 51

-- 4)
krotki_4 = [(a ,b ,c) | a <- [0,1..10] , b <- [0,1..10] , c <- [0,1..10], a/=b, a/=c, b/=c] --take 15 krotki_4          nie wiem czemu nie działa na liście nieskończonej, a powinno
