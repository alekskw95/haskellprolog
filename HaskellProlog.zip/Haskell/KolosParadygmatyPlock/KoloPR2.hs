{-
Zad 1
=====

Napisz predykat

			czyPodzielnaPrzez5iUjemna(X)
			
ktory dla zadanej liczby X wypisze true jeli liczba X jest ujemna i podzielna przez 5, a w przeciwnym razie wypisze false.
-}
czyPodzielnaPrzez5iUjemna :: (Int) -> Bool
czyPodzielnaPrzez5iUjemna x =
    if (x<0 && x `mod` 5 == 0)
        then True
    else
        False


{-
Zad 2
=====

Napisz predykat

			sumaKwadratow(R,X)

ktory dla zadanej listy liczb X wyznaczy sume kwadratow R jej elementow.

Np.

			sumaKwadratow(R,[1,2,3])
			
zwroci

			R=1^2+2^2+3^2=14.-}

sumaKwadratow'' :: ([Int]) -> Int
sumaKwadratow'' [] = 0
sumaKwadratow'' (x:xs) = x^2 + sumaKwadratow'' xs


sumaKwadratow' :: String -> Int -> Int -> Int -> String
sumaKwadratow' r x y z = r ++ " = " ++ show(x) ++ " ^2 + " ++ show(y) ++ " ^2 + " ++ show(z) ++ " ^2 = " ++ show(x^2+y^2+z^2)


sumaKwadratow :: (String, [Int]) -> String
sumaKwadratow (r, x) = r ++  " = " ++ kwadrat(x) ++ "= " ++ show(suma(x))

kwadrat [] = ""
kwadrat [x] = show(x) ++ "^2 "
kwadrat(x:xs) = show(x) ++ "^2 " ++ "+" ++ kwadrat xs

suma[]=0
suma(x:xs) = x^2 + suma xs

{-Zad 3
=====

Zdefiniuj predykat

			delta(A,B,C,R)

ktory dla trzech zadanych liczb A, B i C zwroci R rowne odpowiednio:
a)  -1 jesli A=0,
b)   1 jesli A<>0 i Delta<0,
c)   2 jesli A<>0 i Delta>=0,
gdzie Delta=B^2-4*A*C.-}

delta :: (Int, Int, Int) -> Int
delta (a, b, c)
   | a == 0 = (-1)
   | a /= 0 && ddelta(a, b, c) < 0 = 1
   | a /= 0 && ddelta(a, b, c) >= 0 = 2

   
ddelta(a, b, c) = b^2 - 4*a*c
{-
Zad 4
=====

Napisz program ktory pobierze od uzytkownika trzy liczby i wypisze na ekran najwieksza z nich.-}
dajLiczby :: Int -> Int -> Int -> Int
dajLiczby x y z = max ( max x y) z

dajLiczby2 :: Int -> Int -> Int -> Int
dajLiczby2 x y z
    | x>y && x>z = x
    | y>x && y>z = y
    | z>x && z>y = z
    | otherwise = error "Sprawdz liczby"