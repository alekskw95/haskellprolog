{-Zad. 1. 
=======
Zdefiniować funkcję o nazwie znak, która dla liczby naturalnej n i łańcucha znakowego s poda n-ty znak łańcucha s.-}
znak :: Int -> [Char] -> Char
znak n text = text !! (n-1)--(!!) text n