{-Zad. 3.
======
Zdefiniować funkcję o nazwie para, która dla dwóch list złożonych z liczb utworzy parę uprządkowaną, której pierwszy element jest pierwszym elementem pierwszej listy, zaś drugi - ostatnim elementem drugiej listy. W przypadku, gdy któraś z list jest pusta w wyniku mamy uzyskać parę (0,0).-}

para a b = if a == [] || b == [] then (0,0) else (head a, last b)


para2 _ [] = (0,0)
para2 [] _ = (0,0)
para2 a b = (head a, last b)