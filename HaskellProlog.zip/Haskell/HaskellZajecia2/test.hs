drugi(_,b,_) = b
aa x = "jfhbhvb" ++ x

f1 :: Int -> String
f1 5 = "Na piatke"
f1 7 = "Szczesliwa siodemka"
f1 8 = "Teraz osiem"
f1 x = "Nie wiem, co to jest"

f2 :: Int -> String
f2 x
 |x<=0 = "Bledne dane"
 |x<8 = "Przedszkolak"
 |x<18 = "Pora nauki"
 |otherwise = "Pracuj!!!"

 
kolo r = pi*r*r

kolo1 r = pi*kw
 where kw = r*r
 
 
kolo2 r =
 let kw=r*r
 in pi*kw