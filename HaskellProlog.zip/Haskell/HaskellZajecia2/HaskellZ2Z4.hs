{-Zad. 4.
=======
Zdefiniować funkcję o nazwie sign, która dla  liczby  dodatniej ma wartość 1, dla liczby ujemnej ma wartość -1, a dla liczby 0 ma wartość 0. 
a) Zastosować instrukcję if ... else ...
b) Zastosować strażników (guards).-}

--Zad4a--
signA n = if n>0 then 1 else if n<0 then (-1) else 0

--Zad4b--
-- https://en.wikibooks.org/wiki/Haskell/Control_structures
signB n 
   | n>0 = 1
   | n<0 = (-1)
   | otherwise = 0
