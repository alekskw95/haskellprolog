{-Zad. 2. 
=======
Zdefiniować dwie listy o nazwach listaA, listaB; 
listaA ma być listą 6 uporządkowanych par łańcuchów znakowych - imion i nazwisk pewnych osób;
listaB ma składać się z liczb dwucyfrowych o cyfrach dziesiątek 3, 5 lub 7 i cyfrach jedności 3 lub 4.
a) Zdefiniować listę o nazwie listaA1 składającą się tylko z imion z listy listaA.
b) Zdefiniować listę o nazwie listaA2 składającą się tylko z nazwisk z listy listaA.
c) Zdefiniować listę o nazwie osoby uporządkowanych trójek wszystkich możliwych układów (imie, nazwisko, wiek), gdzie wiek jest z listy listaB.-}

--Zad2--
listaA = zip ["Anna", "Maria", "Karolina", "Ala", "Rafal", "Marcin"] ["Kowalczyk", "Adamowska", "Baran", "Kowalski", "Nowak", "Olejnik"]
listaB = [10*x+y | x<-[3,5,7], y<-[3,4]]

--Zad2a--
listaA1 = map fst listaA

--Zad2b--
listaA2 = map snd listaA

--Zad2c--

osoby1 = [(a, b, c) | a<-listaA1, b<-listaA2, c<-listaB]


--osoby = zip3 listaA1 listaA2 listaB

-- https://www.haskell.org/hoogle/?hoogle=zip3