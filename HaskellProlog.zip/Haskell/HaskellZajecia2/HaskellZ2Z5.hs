{-Zad. 5.
=======
Zdefiniować funkcję, która oblicza pole powierzchni siatki prostopadłościanu o krawędziach o długościach, x, y, z, obliczjąc w pośrednich krokach pole podstawy i pola ścian bocznych.
a) Zastosować konstrukcję  where.
b) Zastosować konstrukcję let ... in ...-}

--a
poleP x y z = 2 * p + h
    where p = x * y
          h = 2 * x * z + 2 * y * z

--b
poleP2 x y z =
   let p = x * y
       h = 2 * x * z + 2 * y * z
   in 2 * p + h
