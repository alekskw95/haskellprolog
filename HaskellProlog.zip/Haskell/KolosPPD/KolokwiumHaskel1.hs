{-
Zadanie 1
=========
Zdefiniuj funkcje 

			iloczynKwadratow n


ktora obliczy iloczyn kwadratow liczb od 1 do n wlacznie.
-}
iloczynKwadratow :: Int -> Int
iloczynKwadratow n = oblicz([1..n])

oblicz [] = 1
oblicz (x:xs) = x^2 * oblicz xs

{-
Zadanie 2
=========

Napisz funkcje

			sumaPrzedzialu a b


ktora zwroci sume liczb naturalnych z przedzialu [a,b] jesli a<=b lub [b,a] jesli b<a (a i b calkowie).

-}

sumaPrzedzialu :: Int -> Int -> Int
sumaPrzedzialu a b =
    if (a<=b)
        then sum [a..b]
    else if (b<a)
        then sum [b..a]
    else
        error "Inny przedzial"

sumaPrzedzialu' :: Int -> Int -> Int
sumaPrzedzialu' a b =
    if (a<=b)
        then sumuj[a..b]
    else if (b<a)
        then sumuj[b..a]
    else
        error "Inny przedzial"

sumuj [] = 0
sumuj (x:xs) = x + sumuj xs

{-sum :: [Int] -> Int
sum [] = 0
sum (x:xs) = x + sum xs-}
{-
Zadanie 3
=========

Napisz program ktory wczytuje z klawiatury trzy liczby calkowite a,b,c i wypisuje na ekran liczbe rozwiazan
rownanania kwadratowego


                        a*x^2 + b*x + c = 0.-}
main = do
    putStr "Podaj a\t"
    a <- getLine
    putStr "Podaj b\t"
    b <- getLine
    putStr "Podaj c\t"
    c <- getLine
    putStrLn $ "Podano a=" ++ a ++ ", b=" ++ b ++ ", c=" ++ c
    putStrLn $ "Rownanie ma : " ++ show(rownanie (read a :: Int) (read b :: Int) (read c :: Int)) ++ " rownan/ia"

rownanie :: Int -> Int -> Int -> String
rownanie x y z =
    if ( ddelta(x)(y)(z) > 0 )
        then "2"
    else if ( ddelta(x)(y)(z) == 0 )
        then "1"
    else if ( ddelta(x)(y)(z) > 0 )
        then "brak"
    else
        "Blad"

ddelta a b c = b^2 - 4*a*c
{-
Zadanie 4
=========

Zdefiniuj funkcje


			elementyDodatnie


ktora pobiera liste liczb calkowitych i zwraca liste tylko dodatnich elementow z tej listy.-}

elementyDodatnie :: [Int] -> [Int]
elementyDodatnie [] = []
elementyDodatnie (x:xs) = if (x>0) then x : elementyDodatnie xs else elementyDodatnie xs