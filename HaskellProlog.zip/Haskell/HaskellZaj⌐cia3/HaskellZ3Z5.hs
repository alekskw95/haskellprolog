{-Zadanie 5
Zdefiniować funkcję 

			mergeLists :: [[a]] -> [a]
			
która zwraca listę utworzoną z wszystkich elementów podlist.

Na przykład:

mergeLists [[1,2,3],[4,8],[9]]

daje nam [1,2,3,4,8,9].-}
{-
mergeLists :: [[a]] -> [a]
mergeLists x = concat x

mergeLists' :: [[a]] -> [a]
mergeLists' [] = []
mergeLists' (x:xs) = x ++ mergeLists' xs

-}
mergeLists :: [[a]] -> [a]
mergeLists [] = error "Pusta lista"
mergeLists [x] = x
mergeLists (x:xs) = x ++ mergeLists xs