{-Zadanie 7
Zdefiniować funkcję

        connectOneAfterOne :: [a] -> [a] -> [a]
		
która zwraca listę elementów pobieranych z dwóch list (podanych jako argumenty), przy czym elementy są pobierane jeden po drugim w kolejności indeksów.

Na przykład:

connectOneAfterOne [1,2,3] [6,7,8,9,10]

daje nam [1,6,2,7,3,8].-}

connectOneAfterOne :: [a] -> [a] -> [a]
connectOneAfterOne [] x = []
connectOneAfterOne x [] = []
connectOneAfterOne (x:xs) (y:ys) = x:y:connectOneAfterOne xs ys