{-Zadanie 3
Zdefiniować ciągi {a_{n}} and {b_{n}}, gdzie

                a_{0}=1, a_{n}=a_{n-1}+b_{n-1}, n=1,2,...,

                b_{0}=1, b_{n}=a_{n-1}*b_{n-1},  n=1,2,...

Utworzyć:
- listę 10 początkowych wyrazów ciągu {a_{n}},
- listę 10 początkowych wyrazów ciągu {b_{n}}.-}

a :: Integer -> Integer
a 0 = 1
a n = (a(n-1)+(a(n-1)))
b :: Integer -> Integer
b 0 = 1
b n = (a(n-1)*(b(n-1)))

listaA = [a x | x <-[1..10]]
listaB = [b x | x <-[1..10]]