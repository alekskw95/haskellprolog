{-Zadanie 6
Zdefiniować funkcję

			howManyTimes :: a -> [a] -> Int
			
której wynikiem jest liczba wystąpień elementu w  liście.

Na przykład:

howManyTimes 'a' "bananas" 

daje nam 3.-}

--howManyTimes :: (Eq a) =>  a -> [a] -> Int
--howManyTimes x xs = (length . filter (== x)) xs

--howManyTimes' :: (Eq a) =>  a -> [a] -> Int
--howManyTimes' _ [] = 0
--howManyTimes' x (y:ys) = (if (x==y) then 1 else 0) + howManyTimes' x ys


howManyTimes :: Char -> [Char] -> Int
howManyTimes ' ' " " = error "Nie ma nic"
howManyTimes x y = length [xs | xs <- y, xs == x]