{-Zadanie 4
Zdefiniować funkcje:

		firstFromList :: [a] -> a
		secondFromList :: [a] -> a
		lastFromList :: [a] -> a
		prelastFromList :: [a] -> a
		
które podają odpowiednio pierwszy, drugi, ostatni i przedostatni element listy będącej argumentem funkcji.-}


firstFromList :: [a] -> a
firstFromList [] = error "blad"
firstFromList (x:_) = x

{-
*Main> firstFromList "bhagak"
'b'
*Main> firstFromList [4,6,8]
4
*Main> firstFromList []
*** Exception: blad
CallStack (from HasCallStack):
  error, called at F:\\DellPulpit\ParadygmatyIJProg\HaskellZajęcia3\HaskellZ3Z4.hs:13:20 in main:Main
*Main>
-}

secondFromList :: [a] -> a
secondFromList [] = error "pusta"
secondFromList [_] = error "tylko jeden element"--jeden element jakikolwiek
secondFromList (_:y:_) = y--y jest drugim elementem

lastFromList :: [a] -> a
lastFromList [] = error "pusta"
--lastFromList (_:xs) = last xs
lastFromList [x] = x
lastFromList (_:xs) = lastFromList xs

prelastFromList :: [a] -> a
prelastFromList [] = error "pusta"
prelastFromList [_] = error "blad"
prelastFromList [x,_] = x
prelastFromList (_:xs) = prelastFromList xs