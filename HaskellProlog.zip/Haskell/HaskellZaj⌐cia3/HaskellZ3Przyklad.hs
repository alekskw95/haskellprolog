suma []=0
suma (x:xs) = x + suma xs

iloczyn []=1
iloczyn (x:xs) = x * iloczyn xs

list1 = [1..5]
list2 = [2..6]

how :: [Int] -> [Int] -> [Int]
how [] [] = error "obie puste"
how x y = [xs + ys | xs<-x, ys<-y]
{-*Main> how [1,2,3][3,2,1]
[4,3,2,5,4,3,6,5,4]-}


how2 :: [Int] -> [Int] -> [Int]
--how2 [] [] = error "obie puste"
how2 xs ys = [x + y | x<-xs, y<-ys]

how3 :: [Int] -> [Int] -> [Int]
--how3 [] [] = error "obie puste"
how3 [] x = []
how3 x [] = []
how3 (x:xs) (y:ys) = x+y:how3 xs ys
{-*Main> how3 [1,2,3] [5,1,2]
[6,3,5]
*Main>-}

how4 :: [Int] -> [Int] -> [Int]
how4 [] x = []
how4 x [] = []
how4 (x:xs) (y:ys) = x+last(ys):how4 xs ys

how5 :: Char -> [Char] -> Int
how5 ' ' " " = error "puste"
how5 x y = length[z | z<-y, z==x]