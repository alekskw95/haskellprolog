{-Zadanie 1
Zdefiniować funkcję

              isPrime :: Int -> Bool
			  
która daje wartość True, gdy liczba podana jako argument jest liczbą pierwszą, a False w przeciwnym razie.

Następnie zdefiniować funkcję 

              nPrimes :: Int -> [Int]
			  
która dla argumentu n wyświetla listę n początkowych liczb pierwszych.

Na przykład:

nPrimes 8

daje nam [2,3,5,7,11,13,17,19].-}

dzielniki :: Integer -> [Integer] --uzyskujemy liste dzielnikow
dzielniki n = [x | x<-[1..n], n `mod` x == 0]

isPrime n = dzielniki n == [1,n]

primes = [x | x<-[2,3..], isPrime x == True] --lista wszystkich liczb pierwszych, isPrime dla x == True
--takeWhile (<150) primes

