{-Zadanie 2
Zdefiniować ciąg {c_{n}}, gdzie c_{1}=1, c_{n}=1+2*c_{n-1} dla n=2,3,...

a) Wyświetlić c_{15}.

b) Utworzyć listę 15 początkowych wyrazów ciągu{c_{n}}.

c) Zdefiniować funkcję, która dla argumentu n wyświetla listę n początkowych wyrazów ciągu {c_{n}}.

d) Utworzyć listę wyrazów ciągu {c_{n}} mniejszych od 1000.-}

--a)
c :: Int -> Int
c 1 = 1
c n = 1+2*(c (n-1)) --jak nie trafi na 1 przejdzie do n

--b)
listaC = [c x | x<-[1..15]]--dla 16 to do 1 do n-1 -- wywolanie listaC

--c)
funkcjaA n = [c x | x<-[1..n]]--funkcjaA 15

--d)
funkcjaB = takeWhile(<1000)[c x | x<-[1..]]

