import System.IO
{-
Zad. 1. 
=======
Napisać program (lub funkcję), który wyświetla na ekranie zawartość podanego pliku.-}
main = do
   handle <-  openFile "F:\\DellPulpit\\ParadygmatyIJProg\\HaskellZajęcia5\\file.txt" ReadMode
   contents <- hGetContents handle  
   putStr contents
   hClose handle
   
{-Zad. 2. 
=======
Napisać program (lub funkcję), który zapisuje do pliku tekst podany przez użytkownika.-}

main1B = do
   putStrLn "What is your name?"
   inpStr <- getLine
   putStrLn $ "Welcome to Haskell, " ++ inpStr ++ "!"
   writeFile  "F:\\DellPulpit\\ParadygmatyIJProg\\HaskellZajęcia5\\file2.txt" (inpStr)

{-
Zad. 3. 
=======
Napisać program (lub funkcję), który wczytuje zawartość pliku tekstowego, a następnie zapisuje w nowym pliku 
pobrane wiersze w kolejności odwrotnej do wyjściowej. Nazwy plików mają być argumentami odpowiedniej funkcji.-}

reverseLines :: String -> String -> IO ()
reverseLines x y = do
    handle <- openFile x ReadMode
    contents <- hGetContents handle
    writeFile ("F:\\DellPulpit\\ParadygmatyIJProg\\HaskellZajęcia5\\"++y) (reverse contents)
    putStrLn $ " Tekst zapisano "
    hClose handle

{-
Zad. 4. 
=======
Napisać program (lub funkcję), który wczytuje zawartość pliku, a następnie wyświetla:
a) liczbę wierszy w tym pliku,
b) liczbę słów w tym pliku,
c) liczbę liter w tym pliku,
d) liczbę znaków róznych od spacji w tym pliku.-}
readPlik = do
   putStrLn "Podaj nazwe pliku do odczytania"
   plik <- getLine
   readLines plik
   readWords plik
   readDigit plik
   readChar plik

readLines :: String -> IO ()
readLines fileName = do
   handle <- openFile fileName ReadMode
   contents <- hGetContents handle
   let amount = length $ lines contents
   putStrLn $ show amount
   hClose handle

isLower :: Char -> Bool
isLower c = c >= 'a' && c <= 'z'

readWords :: String -> IO ()
readWords fileName = do
   handle <- openFile fileName ReadMode
   contents <- hGetContents handle
   let amount = length $ words contents
   putStrLn $ show amount
   hClose handle

litera x 
   | x >= 'a' && x <= 'z' = True
   | x >= 'A' && x <= 'Z' = True
   | otherwise = False
   
readDigit :: String -> IO ()
readDigit fileName = do
   handle <- openFile fileName ReadMode
   contents <- hGetContents handle
   let amount = length $ filter litera contents
   putStrLn $ show amount
   hClose handle
   
readChar :: String -> IO ()
readChar fileName = do
   handle <- openFile fileName ReadMode
   contents <- hGetContents handle
   let amount = length $ filter (/=' ') [x|x<-contents]
   putStrLn $ show amount
   hClose handle