import System.IO
import Data.Char
import Data.List
import System.Random
{-
Zad. 1. 
=======
Napisać program (lub funkcję), który wyświetla na ekranie zawartość podanego pliku.-}
main = do
   handle <-  openFile "F:\\DellPulpit\\ParadygmatyIJProg\\HaskellZajęcia5\\file.txt" ReadMode
   contents <- hGetContents handle  
   putStr contents
   hClose handle

zPliku = do
   putStr "Podaj nazwę pliku :"
   nazwa <- getLine
   handle <- openFile nazwa ReadMode
   tekst <- hGetContents handle
   putStr tekst
   putStr " \n "
   hClose handle


zPliku' = do
   putStr "Podaj nazwę pliku :"
   nazwa <- getLine
   tekst <- readFile nazwa
   putStrLn "-----------------"
   putStrLn tekst

{-Zad. 2. 
=======
Napisać program (lub funkcję), który zapisuje do pliku tekst podany przez użytkownika.-}

doPliku = do
   putStr "Podaj napis :"
   napis <- getLine
   --putStrLn $ napis
   writeFile  "F:\\DellPulpit\\ParadygmatyIJProg\\HaskellZajęcia5\\file2.txt" (napis)

{-
Zad. 3. 
=======
Napisać program (lub funkcję), który wczytuje zawartość pliku tekstowego, a następnie zapisuje w nowym pliku 
pobrane wiersze w kolejności odwrotnej do wyjściowej. Nazwy plików mają być argumentami odpowiedniej funkcji.-}

fileToFile file1 file2 = do
   contents <- readFile file1
   writeFile file2 (unlines . reverse . lines $ contents)

reverseLines :: String -> String -> IO ()
reverseLines x y = do
    handle <- openFile x ReadMode
    contents <- hGetContents handle
    writeFile ("F:\\DellPulpit\\ParadygmatyIJProg\\HaskellZajęcia5\\"++y) (reverse contents)
    putStrLn $ " Tekst zapisano "
    hClose handle

{-
Zad. 4. 
=======
Napisać program (lub funkcję), który wczytuje zawartość pliku, a następnie wyświetla:
a) liczbę wierszy w tym pliku,
b) liczbę słów w tym pliku,
c) liczbę liter w tym pliku,
d) liczbę znaków róznych od spacji w tym pliku.-}

readPlik = do
   putStrLn "Podaj nazwe pliku: "
   plik <- getLine
   readTXT plik

readTXT :: String -> IO ()
readTXT fileName = do
   handle <- openFile fileName ReadMode
   contents <- hGetContents handle
   let wiersze = length $ lines contents
   let slowa = length $ words contents
   let litery = length $ filter litera contents
   let znaki = length $ filter (/=' ') [x|x<-contents]
   putStrLn $ " Tekst zawiera: " ++ " \n wiersze: " ++ show(wiersze) ++ " \n slowa: " ++ show(slowa) ++ " \n litery: " ++ show(litery) ++ " \n znaki bez spacji: " ++ show(znaki)
   hClose handle
   
litera x 
   | x >= 'a' && x <= 'z' = True
   | x >= 'A' && x <= 'Z' = True
   | otherwise = False


{-

Zad. 5. 
=======
Napisać program (lub funkcję), który po wczytaniyu liczby naturalnej n wyświetla listę n poczštkowych liczb 
cišgu Fibonacci'ego.-}

fibonacci :: Int -> Int
fibonacci n
    | n < 3 = 1
    | otherwise = fibonacci(n-2) + fibonacci(n-1)

fibonacciFun n = [fibonacci x | x<-[1..n]] 


fib :: Int -> Integer 
fib 1 = 1
fib 2 = 1
fib n = fib (n-1) + fib (n-2)

fib' :: Int -> Integer
fib' n = fst $ sequence !! n
  where
    sequence = iterate (\(x, y) -> (y, x + y)) (0, 1)

fibResult n = [fib' x | x <- [0..n]]
{-
Zad. 6. 
=======
Zdefiniować funkcję, która symuluje trzykrotny rzut moneta. -}

--	
losuj = do  
   gen <- newStdGen  
   putStrLn $ take 4 (randomRs ('1','6') gen)

