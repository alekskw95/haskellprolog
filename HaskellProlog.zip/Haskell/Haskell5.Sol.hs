import System.IO

--Ex 1
main = do
   handle <-  openFile "F:\\DellPulpit\\ParadygmatyIJProg\\file.txt" ReadMode
   contents <- hGetContents handle  
   putStr contents
   hClose handle


--Ex 2

main1 = do 
   contents <- readFile "F:\\DellPulpit\\ParadygmatyIJProg\\file.txt"
   writeFile  "F:\\DellPulpit\\ParadygmatyIJProg\\bb.txt" (contents)
   
--Ex 3
 
writeMinMax = do
   putStrLn "Podaj plik do zapisu"
   plik <- getLine
   handle <- openFile plik WriteMode
   hPutStrLn handle (show (maximum [1,2,3,4,5]))
   hPutStrLn handle (show (minimum [1,2,3,4,5]))
   hClose handle
   
--Ex 4

czytajPlik = do
   putStrLn "Podaj nazwe pliku do odczytania"
   plik <- getLine
   readLines plik
   readWords plik
   readChar plik

readLines :: String -> IO ()
readLines fileName = do
   handle <- openFile fileName ReadMode
   contents <- hGetContents handle
   let amount = length $ lines contents
   putStrLn $ show amount
   hClose handle

readWords :: String -> IO ()
readWords fileName = do
   handle <- openFile fileName ReadMode
   contents <- hGetContents handle
   let amount = length $ words contents
   putStrLn $ show amount
   hClose handle

readChar :: String -> IO ()
readChar fileName = do
   handle <- openFile fileName ReadMode
   contents <- hGetContents handle
   let amount = length $ filter (/=' ') contents
   putStrLn $ show amount
   hClose handle   