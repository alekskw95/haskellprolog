
-- dodaje od końca i wyniki są w takiej kolejności w jakiej dodaje 
dodajEnd :: [Integer] -> [Integer] -> [Integer]
dodajEnd [] [] = []
dodajEnd xs [] = lastFromList xs : dodajEnd (init xs) []
dodajEnd [] xs = lastFromList xs : dodajEnd [] (init xs)
dodajEnd x y = lastFromList x + lastFromList y : dodajEnd (initList' x) (initList' y)

--odwraca wyniki z dodajEnd
dodajEnd' x y = obrocListe $ dodajEnd x y 

-- dodaje od końca i jak któraś lista jest pusta to przerywa dodawanie
dodajEnd'' :: [Integer] -> [Integer] -> [Integer]
dodajEnd'' [] _ = []
dodajEnd'' _ [] = []
dodajEnd'' x y = lastFromList x + lastFromList y : dodajEnd'' (initList' x) (initList' y)

lastFromList [] = error "blad - lista pusta"
lastFromList [x] = x
lastFromList (_:xs) = lastFromList xs

initList' [] = error "blad - lista pusta"
initList' [x] = []
initList' (x:xs) = x: initList' xs

obrocListe :: [a] -> [a]
obrocListe [] = []
obrocListe (x: xs ) = obrocListe xs ++ [ x]

{-
*Main> dodajEnd [1,2,3] [4,5,6]
[9,7,5]
*Main> dodajEnd' [1,2,3] [4,5,6]
[5,7,9]
*Main> dodajEnd'' [1,2,3] [4,5,6]
[9,7,5]
*Main> dodajEnd'' [1,2,3] [4,5,6,8,9]
[12,10,7]
*Main>-}