import System.IO
--Zadanie 5
main = do
   handle <-  openFile "F:\\DellPulpit\\ParadygmatyIJProg\\file.txt" ReadMode
   contents <- hGetContents handle  
   putStr contents
   hClose handle
   
--Zadanie 6
{-main1 = do 
   contents <- readFile "F:\\DellPulpit\\ParadygmatyIJProg\\file.txt"
   writeFile  "F:\\DellPulpit\\ParadygmatyIJProg\\file2.txt" (contents)-}

main1B = do
   putStrLn "What is your name?"
   inpStr <- getLine
   putStrLn $ "Welcome to Haskell, " ++ inpStr ++ "!"
   writeFile  "F:\\DellPulpit\\ParadygmatyIJProg\\file2.txt" (inpStr)

--Zadanie 7
readPlik = do
   putStrLn "Podaj nazwe pliku do odczytania"
   plik <- getLine
   readLines plik
   readWords plik
   readDigit plik
   readChar plik

readLines :: String -> IO ()
readLines fileName = do
   handle <- openFile fileName ReadMode
   contents <- hGetContents handle
   let amount = length $ lines contents
   putStrLn $ show amount
   hClose handle

isLower :: Char -> Bool
isLower c = c >= 'a' && c <= 'z'

readWords :: String -> IO ()
readWords fileName = do
   handle <- openFile fileName ReadMode
   contents <- hGetContents handle
   let amount = length $ words contents
   putStrLn $ show amount
   hClose handle

litera x 
   | x >= 'a' && x <= 'z' = True
   | x >= 'A' && x <= 'Z' = True
   | otherwise = False
   
readDigit :: String -> IO ()
readDigit fileName = do
   handle <- openFile fileName ReadMode
   contents <- hGetContents handle
   let amount = length $ filter litera contents
   putStrLn $ show amount
   hClose handle
   
readChar :: String -> IO ()
readChar fileName = do
   handle <- openFile fileName ReadMode
   contents <- hGetContents handle
   let amount = length $ filter (/=' ') [x|x<-contents]
   putStrLn $ show amount
   hClose handle