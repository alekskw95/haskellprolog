% Zadanie 3 Zdefiniuj predykat w Prologu

	% czyListaDwuelementowa(X)

% ktory zwroci true lub false w zaleznosci od tego czy parametr X jest
% lista dwuelementowa czy nie jest.

czyListaDwuelementowa([_,_]). % :- dlugosc(X, _) == 2.

dlugosc([],0).
dlugosc([_|Xs], L) :- dlugosc(Xs,L1), L is L1+1.




% Zadanie 4 Napisz wlasny predykat min2 ktory wyznaczy min z dwoch liczb, 
% a nastepnie wykorzystujac ta funkcje napisz program w Prologu, 
% ktory odczyta z klawiatury dwie liczby i wypisze na ekran mniejsza z nich.

min2(X, Y) :- X < Y -> write(X); Y < X -> write(Y).

podaj :- write('Podaj X: '), read(X),
	     write('Podaj Y: '), read(Y),
		 write('Mniejsza: '), min2(X,Y).