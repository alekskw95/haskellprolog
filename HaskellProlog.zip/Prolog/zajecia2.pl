%1) Zdefiniowa� predykat max2(X,Y,Z), kt�ry jest spe�niony, gdy liczba Z jest r�wna maksimum liczb X, Y.

max2(X,Y,Z) :- X>=Y, Z=X.
max2(X,Y,Z) :- X=<Y, Z=Y.

maxx(X,Y,Z) :- X>=Y -> Z=X; Z=Y.

%2) Zdefiniowa� predykat isList(X), kt�ry jest spe�niony, gdy X jest list�.

isList([]). %pusta lista jest lista
isList([_|Y]) :- isList(Y).

%3) Zdefiniowa� predykat isMember(X,L), kt�ry jest spe�niony, gdy X jest elementem listy L.

isMember(X,[X|_]). %jezeli mam element X  i jest on elementem pierwszym listy
isMember(X, [_|T]) :- isMember(X,T). %spr czy jest elementem ogona

%4) Zdefiniowa� predykat myLast(X,L), kt�ry jest spe�niony, gdy X jest ostatnim elementem listy L.

myLast(X, [X]).
myLast(X, [_|T]) :- myLast(X,T).

%5) Zdefiniowa� predykat multiply(L1,L2,L), kt�ry jest spe�niony, gdy lista L sk�ada si� 
% z iloczyn�w odpowiednich (na tych samych pozycjach) element�w list L1, L2.

multiply([X],[Y],[Z]) :- Z is X*Y.
multiply([X|Xs], [Y|Ys], L) :- Z is X*Y, multiply(Xs, Ys, Ls), L=[Z|Ls].

%6) wektor przez skalar, lista liczba powstaje lista zlozona z el listy pomnozonych przez liczbe

timesA(A,[X],[L]) :- L is A*X.
timesA(A, [X|Xs], L) :- Z is A*X, L=[Z|Ls], timesA(A, Xs, Ls). 

%7)suma elementow listy
sum([], 0).
sum([X|Xs], S) :- sum(Xs, S1), S is X+S1.

%8) dlugosc listy
dlugosc([], 0).
dlugosc([X|Xs], L) :- dlugosc(Xs, L1), L is L1+1.