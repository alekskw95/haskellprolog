% Zadanie 1
% Zdefiniuj w Prologu rekurencyjną funkcję dodajListy(A,B,R) który 
% dla dwóch danych list liczbowych A i B utworzy listę R sum jej elementów 
% na odpowiadających sobie pozycjach. Np. dodajListy([1,2,3],[4,5,6],R). R=[5,7,9]

dodajListy([],[],0).
dodajListy([X], [Y], [Z]):- Z is X+Y.
dodajListy([X|Xs],[Y|Ys], L):-  Z is X+Y, dodajListy(Xs, Ys, Ls), L=[Z|Ls].

% dodajListy([],[],0).
% dodajListy([X|Xs],[Y|Ys],R):- dodajListy(Xs, Ys, R1), R=[X+Y|R1].


% Zadanie 2
% Zdefiniuj w Prologu predykat max2(X,Y,Z) który dla dwóch liczb X i Y 
% wyznaczy większą z nich, a następnie napisz w Prologu program, 
% który odczyta z klawiatury dwie liczby (zakładamy , że użytkownik musi je podać) 
% i jeśli są one obie dodatnie to do pliku plik.txt zapisze maximum z tych liczb, 
% a w przeciwnym przypadku do pliku plik.txt zapisze liczbę -1.

max2(X,Y,Z) :- X >= Y, Z=X.
max2(X,Y,Z) :- Y >= X, Z=Y.


max22(X, Y) :- 
( X>=Y->
	(Z is X,
	 write(Z)
	);
	(Z is Y,
	 write(Z)
	)
).
	
maxx(A, B, S) :- A>=0, B>=0, S is max(A,B).
maxx(A, B, S) :- (A<0; B<0), S is -1.
	
czytaj:- write('Podaj a '), read(A),
		 write('Podaj b '), read(B),
		 write('Podano '), write(A), write(', '), write(B),
		 open('plik.txt', write, X),
		 current_output(COUT),
		 set_output(X),
		 %maxx(A, B, S),
		 (A>0, B>0 -> max2(A,B,S), write(S); Z is -1, write(Z)),	
		 %write(S),
		 close(X),
		 set_output(COUT).

	 
/**czytaj:- write('Podaj a'), read(A),
		 write('Podaj b'), read(B),
		 write('Podano'), write(A), write(', '), write(B),
		 open('plik.txt', write, X),
		 current_output(COUT),
		 set_output(X),
		 ((A>0, B>0) -> W is max(A,B); W is -1), write(W),
		 close(X),
		 set_output(COUT).
*/


