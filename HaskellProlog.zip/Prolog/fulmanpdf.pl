silnia(0,F) :- F is 1.
silnia(N1,F1) :- N1>0,N2 is N1-1,
silnia(N2,F2),F1 is N1*F2.

fib(0,F) :- F is 1.
fib(1,F) :- F is 1.
fib(N,F):- N>1,N1 is N-1,N2 is N-2,
			fib(N1,F1),
			fib(N2,F2),F is (F1 + F2).
			
usun(X,[X|Xs],Xs).
usun(X,[Y|Ys],[Y|Zs]) :- usun(X,Ys,Zs).

usunAll(_,[],[]).
usunAll(X,[X|T],Z) :- !, usunAll(X,T,Z).
usunAll(X,[Y|T1],[Y|T2]) :- usunAll(X,T1,T2).

%elementSzukany,NowyElement,Lista,Wynik
zamien(_,_,[],[]).
zamien(X,Y,[X|T1],[Y|T2]) :- !, zamien(X,Y,T1,T2).
zamien(X,Y,[Z|T1],[Z|T2]) :- !, zamien(X,Y,T1,T2).

dodajDoListy([],[],0).
dodajDoListy(X,Y,R) :- dodajDoListy(X,Y,R,[]).
dodajDoListy([],[],Y,R) :- reverse(R,Y).
dodajDoListy([X|XS],[Y|YS],R,Acc) :- Z is X+Y, dodajDoListy(XS,YS,R,[Z|Acc]).


polacz([],L,L).
polacz([H|T],L,[H|Res]) :- polacz(T,L,Res).
