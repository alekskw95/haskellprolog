% Zad 1 Napisz predykat czyPodzielnaPrzez3iDodatnia(X), ktory dla zadanej liczby X 
% wypisze true jeli liczba X jest dodatnia i podzielna przez 3, 
% a w przeciwnym razie wypisze false.

czyPodzielnaPrzez3iDodatnia(X) :- X > 0, 0 is mod(X,3).

% Zad 2 Napisz predykat
	% sumaKwadratow(R,X)
% ktory dla zadanej listy liczb X wyznaczy sume kwadratow R jej elementow.
% Np.
	% sumaKwadratow(R,[1,2,3])
% zwroci
	% R=1^2+2^2+3^2=14.

sumaKwadratow(R,[]) :- R is 0.
sumaKwadratow(R, [X|Xs]) :- sumaKwadratow(R1, Xs), R is R1+X^2.


% Zad 3 Zdefiniuj predykat
	% delta(A,B,C,R)
% ktory dla trzech zadanych liczb A, B i C zwroci R rowne odpowiednio:
% a)  -1 jesli A=0,
% b)   1 jesli A<>0 i Delta<0,
% c)   2 jesli A<>0 i Delta>=0,
% gdzie Delta=B^2-4*A*C.


delta(A, B, C, R) :- A == 0 , R is -1; A\=0, D is (B^2)-4*A*C, D<0, R is 1; A\=0, D>=0, R is 2.

% Zad 4 Napisz program ktory pobierze od uzytkownika trzy liczby 
% i wypisze na ekran najwieksza z nich.

czytaj :- write('Podaj a '), read(A),
		  write('Podaj b '), read(B),
		  write('Podaj c '), read(C),
		  write('Podano: '), write(A), write(', '), write(B), write(', '), write(C),
		  %write('Najwieksza: '), W is wieksza(A, B, C), write(W).
		  write(' Najwieksza: '), do_something(A, B, C).
		  
		  
do_something(A, B, C):-	A>=B, A>=C -> write(A); B>=A, B>=C -> write(B); C>=B, C>=A -> write(C).  	  
		     

