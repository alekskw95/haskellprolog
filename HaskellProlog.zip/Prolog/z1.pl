firma(abc).
firma(klm).
firma(mno).

kobieta(anna).
kobieta(maria).
kobieta(julia).
kobieta(ewa).
kobieta(joanna).
kobieta(lena).
kobieta(teresa).
kobieta(zuzanna).

mezczyzna(jan).
mezczyzna(karol).
mezczyzna(piotr).
mezczyzna(tomasz).
mezczyzna(lukasz).
mezczyzna(marek).
mezczyzna(jozef).

% pracownik(imie, nazwisko, firma, staz_pracy).

pracownik(anna, klimczak, firma(abc), 10).
pracownik(anna, maj, firma(abc), 1).
pracownik(maria, jankowska, firma(abc), 12).
pracownik(julia, klimczak,  firma(abc), 4).
pracownik(jan, kowal, firma(abc), 21).
pracownik(karol, lis, firma(abc), 5).
pracownik(anna, lis, firma(klm), 12).
pracownik(piotr, bednarek, firma(klm), 8).
pracownik(tomasz, bednarek, firma(klm), 2).
pracownik(ewa, wilk, firma(klm), 3).
pracownik(ewa, lipiec,firma(klm), 7).
pracownik(lukasz, polak,  firma(klm), 11).
pracownik(marek, doba, firma(klm), 8).
pracownik(anna, just, firma(mno), 22).
pracownik(joanna, wilk, firma(mno), 16).
pracownik(piotr, czekaj, firma(mno), 4).
pracownik(maria, wilczak, firma(mno), 16).
pracownik(piotr, kawa, firma(mno), 14).
pracownik(marek, czubak, firma(mno), 5).
pracownik(marek, lis, firma(mno), 4).

%3a
pracownik_abc(X, Y) :- pracownik(X,Y,firma(abc),_).

%3b
prac_Inne(X, Y) :- pracownik(X, Y, F, _) , F \= firma(abc).

%3c
pracKobieta(X,Y) :- pracownik(X,Y,_,_) , kobieta(X).

%3d
dlugoletniPrac(X,Y,Z) :- pracownik(X,Y,firma(Z),S) , S>=10. 

%3e
plus(X,Y,Z) :- Z is X+Y.
premia(X,Y,B) :- pracownik(X,Y,_,S) , B is S*150.

premiaM(X,Y,B) :- pracownik(X,Y,_,S) , S>5 -> B is S*150; B is 0.

% Zadania:
% =========

% 1) Sprawdzi�, czy:

% a) w bazie jest kobieta o imieniu lidia;

% b) w bazie jest pracownik o imieniu jan;

% c) w bazie jest pracownik o imieniu jozef;

% d) w bazie jest pracownik o nazwisku karolak;

% e) w firmie abc jest pracownik o nazwisku maj.

 
% 2) Wy�wietli�:

% a) nazwiska wszystkich pracownik�w o imieniu anna;

% b) imiona i sta� pracy wszystkich pracownik�w o nazwisku lis;

% c) nazwy firm, w kt�rych s� pracownicy o nazwisku lis;

% d) imiona i nazwiska pracownik�w firmy klm;

% e) imiona i nazwiska pracownik�w, kt�rzy s� mezczyznami.



% 3) Stosuj�c odpowiednie regu�y zdefiniowa�:

% a) predykat pracownik_abc(X,Y), kt�ry jest spe�niony, gdy osoba o imieniu X i nazwisku Y jest pracownikiem firmy abc;

% b) predykat pracInne(X,Y), kt�ry jest spe�niony, gdy osoba o imieniu X i nazwisku Y jest pracownikiem firmy innej ni� abc;

% c) predykat pracKobieta(X,Y), kt�ry jest spe�niony, gdy osoba o imieniu X i nazwisku Y jest pracownikiem - kobiet�.

% d) predykat dlugoletniPrac(X,Y,Z), kt�ry jest spe�niony, gdy osoba o imieniu X i nazwisku Y pracuje w firmie Z i ma sta� pracy co najmniej 10 lat;

% e) predykat premia(X,Y,B), kt�ry jest spe�niony, gdy pracownikowi o imieniu X i nazwisku Y przys�uguje premia o warto�ci B; premia dla pracownika wynosi 150 PLN za ka�dy rok pracy.


iloczynKwadratow([], 1).
iloczynKwadratow([X|Xs],Y) :- iloczynKwadratow(Xs, Y1), Y is Y1 * X^2.

signumLiczb(A, B, C) :- A>B -> C is 1; A<B ->C is -1; A==B -> C is 0.