% Zad 1 Napisz program z wykorzystaniem rekurencji mnozacy przez siebie
% dwie liczby naturalne. Wsk. wykorzystaj zaleznosc x*y = x*(y-1)+x

mnoz(0,_,0).
mnoz(1,X,X).
mnoz(X,Y,R) :- X > 1, X1 is X-1, mnoz(X1,Y,R1), R is R1 + Y.



% Zad 2 Napisz predykat

	% iloczynDodatnich(X,Y)
	
% ktory dla zadanej listy liczb X wyznaczy iloczyn Y jej dodatnich elementow
% (w przypadku listy o ujemnych elementach ma byc zwrocona liczba 1).
% Prostsza wersja napisz predykat

	% iloczyn(X,Y)
	
% ktory dla zadanej listy liczb X wyznaczy jej iloczyn.

iloczynDodatnich([],1).
iloczynDodatnich([X|Xs], Y) :- 
								X>0, iloczynDodatnich(Xs, Y1), Y is X*Y1;
								X=<0, iloczynDodatnich(Xs, Y1), Y is 1*Y1.

iloczyn([], 1).
iloczyn([X|Xs], Y) :- iloczyn(Xs, Y1), Y is X*Y1.



% Zad 3 Zdefiniuj predykat

			% signumX(A,B)

% ktory dla zadanej liczby A zwroci:
% a) -1 jesli liczba A jest ujemna,
% b)  0 jesli liczba A jest rowna 0,
% c)  1 jesli liczba A jest dodatnia.

signumX(A, B) :- A<0, B is -1; A==0, B is 0; A>0, B is 1.


% Zad 4 Napisz program ktory pobierze od uzytkownika trzy liczby i zapisze do pliku
% tekstowego plik.txt srodkowa z tych liczb.
% Ustalmy, ze liczba srodkowa wsrod liczb x,y,z jest np. liczba x o ile
% y <= x <= z
% lub 
% z <= x <= y. 

licz(A, B, C, L):- A >= min(B,C) , A =< max(B,C) -> L is A ; 
				   B >= min(A,C) , B =< max(A,C)-> L is B;
				   C >= min(A,B) , C =< max(A,B) -> L is C.		
	
zapisz :- write('Podaj a '), read(A),
		  write('Podaj b '), read(B),
		  write('Podaj c '), read(C),
		  write('Podano: '), write(A), write(', '), write(B), write(', '), write(C),
		  open('plik2.txt', write, X),
		  current_output(COUT),
		  set_output(X),
		  licz(A, B, C, L),
		  write(L),
		  close(X),
		  set_output(COUT).
		  	  
