%ze strony Łazińskiej:
my_flatten(X,[X]) :- \+ is_list(X).
my_flatten([],[]).
my_flatten([X|Xs],Z) :- my_flatten(X,Y), my_flatten(Xs,Ys), append(Y,Ys,Z).

%II sposob
flatten2([], []) :- !.
flatten2([L|Ls], FlatL) :-
    !,
    flatten2(L, NewL),
    flatten2(Ls, NewLs),
    append(NewL, NewLs, FlatL).
flatten2(L, [L]).

%III sposob
flatArray([],[]).
flatArray([Head|Tail],R) :-
	flatArray(Head,New_Head),
	flatArray(Tail,New_Tail),
	append(New_Head,New_Tail,R).
flatArray([Head|Tail1], [Head|Tail2]) :-
	Head \= [],
	Head \= [_|_],
flatArray(Tail1,Tail2).